# This file marks this directory as a Python package.
# You can optionally expose package-level variables or version info here.

__version__ = "v.1.1.7"  # format v.x.y.z

# Optionally, import key functions/classes for easier access
# from .util import get_version